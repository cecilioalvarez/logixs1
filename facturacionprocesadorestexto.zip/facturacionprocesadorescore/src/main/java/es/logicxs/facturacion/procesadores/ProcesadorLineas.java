package es.logicxs.facturacion.procesadores;

import es.logicxs.facturacion.bo.Factura;

public abstract class ProcesadorLineas {
	
	
	public static ProcesadorLineas getInstance(String tipo) {
		
		if (tipo.equals("html")) {
			
			try {
				return (ProcesadorLineas) Class.forName("es.logicxs.facturacion.procesadores.ProcesadorLineasHtml").newInstance();
			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			
			try {
				return (ProcesadorLineas) Class.forName("es.logicxs.facturacion.procesadores.ProcesadorLineasTexto").newInstance();
			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	
	
	public Factura procesarLinea(String linea) {
		
		
		String[] items=linea.split(",");
		Factura f= new Factura(Integer.parseInt(items[0]),items[1],Integer.parseInt(items[2]));
		return f;
	}

}
