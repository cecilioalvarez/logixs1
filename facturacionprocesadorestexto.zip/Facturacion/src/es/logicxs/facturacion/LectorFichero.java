package es.logicxs.facturacion;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class LectorFichero {

	private String nombreFichero;


	public String getNombreFichero() {
		return nombreFichero;
	}

	public void setNombreFichero(String nombreFichero) {
		this.nombreFichero = nombreFichero;
	}

	public List<String> leerLineas() throws IOException {
		
		 Path filePath = Paths.get(nombreFichero);
		 List<String> lines = Files.readAllLines(filePath, StandardCharsets.UTF_8);
		return lines;
	}



	public LectorFichero(String nombreFichero) {
		super();
		this.nombreFichero = nombreFichero;
	}
	
	
}
