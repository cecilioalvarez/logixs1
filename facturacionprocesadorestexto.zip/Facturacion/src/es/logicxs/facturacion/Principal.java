package es.logicxs.facturacion;

import java.io.IOException;
import java.util.List;

import es.logicxs.facturacion.procesadores.ProcesadorLineas;

import es.logicxs.facturacion.bo.Factura;

public class Principal {

	public static void main(String[] args) {

		//es que no usa las clases de Procesadorlineahtml o ProcesadorLienalineaTexto
		
		
		LectorFichero lector = new LectorFichero("facturas.html");
		// quiero que pases por aqui 
		// por el creador de procesadores
		
		ProcesadorLineas procesador= ProcesadorLineas.getInstance("html");
		
		try {
			List<String> lista = lector.leerLineas();
			
			for (String linea: lista) {
				
				Factura f= procesador.procesarLinea(linea);
				
				System.out.println(f.getConcepto());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
