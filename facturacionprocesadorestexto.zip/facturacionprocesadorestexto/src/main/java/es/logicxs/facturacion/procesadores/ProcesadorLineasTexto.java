package es.logicxs.facturacion.procesadores;

import es.logicxs.facturacion.bo.Factura;

class ProcesadorLineasTexto extends ProcesadorLineas {
	
	
	public Factura procesarLinea(String linea) {
		
		
		String[] items=linea.split(",");
		Factura f= new Factura(Integer.parseInt(items[0]),items[1],Integer.parseInt(items[2]));
		return f;
	}

}
